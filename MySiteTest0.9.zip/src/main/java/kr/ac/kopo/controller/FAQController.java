package kr.ac.kopo.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.ibatis.session.SqlSession;
import kr.ac.kopo.mybatis.MyConfig;
import kr.ac.kopo.board.vo.FAQVO;

import java.util.List;

public class FAQController implements Controller {
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String action = request.getParameter("action");

        try (SqlSession sqlSession = new MyConfig().getInstance()) {
            if ("list".equals(action)) {
                // 모든 FAQ 조회
                List<FAQVO> faqList = sqlSession.selectList("FAQMapper.getAllFAQs");
                request.setAttribute("faqList", faqList);
                return "/jsp/board/faqList.jsp";

            } else if ("add".equals(action)) {
                // FAQ 추가
                FAQVO faq = new FAQVO();
                faq.setQuestion(request.getParameter("question"));
                faq.setAuthor(request.getParameter("author")); // 로그인 사용자 이름

                sqlSession.insert("FAQMapper.insertFAQ", faq);
                sqlSession.commit();
                return "redirect:/board/faq.do?action=list";

            } else if ("delete".equals(action)) {
                // FAQ 삭제
                int faqId = Integer.parseInt(request.getParameter("faqId"));
                sqlSession.delete("FAQMapper.deleteFAQ", faqId);
                sqlSession.commit();
                return "redirect:/board/faq.do?action=list";
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("FAQ 처리 중 오류 발생", e);
        }

        return "/jsp/board/faqList.jsp";
    }
}
